package de.schocken.tracker;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(16,17,20), panel=Color.rgb(29,31,37), yellow=Color.rgb(245,197,66), red=Color.rgb(239,83,80), white=Color.WHITE, muted=Color.rgb(165,169,180);
    ArrayList<Player> players=new ArrayList<>(); LinearLayout root, list; EditText nameInput; Spinner fromSpinner,toSpinner; int reserve=13;
    class Player { String name; int yellow=0; int reds=0; Player(String n){name=n;} }
    public void onCreate(Bundle b){super.onCreate(b); players.add(new Player("Spieler 1"));players.add(new Player("Spieler 2"));players.add(new Player("Spieler 3")); render();}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    Button button(String s,int color,Runnable action){Button b=new Button(this);b.setText(s);b.setTextColor(bg);b.setAllCaps(false);b.setTextSize(14);b.setTypeface(null,Typeface.BOLD);b.setBackground(shape(color,22));b.setOnClickListener(v->action.run());return b;}
    void render(){
      root=column();root.setBackgroundColor(bg);root.setPadding(18,18,18,18);
      ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
      LinearLayout header=row();header.addView(text("SCHOCKEN",25,white,true),new LinearLayout.LayoutParams(0,-2,1));header.addView(text("PUNKTEZÄHLER",10,yellow,true));root.addView(header);
      TextView sub=text("Scheiben verteilen. Spiel im Flow.",14,muted,false);sub.setPadding(0,4,0,18);root.addView(sub);
      int used=0;for(Player p:players)used+=p.yellow;
      LinearLayout bank=column();bank.setBackground(shape(panel,18));bank.setPadding(14,14,14,14);
      bank.addView(text("GEMEINSAMER VORRAT",12,muted,true));bank.addView(text("🟡 "+(13-used)+" von 13 gelben Scheiben frei",20,yellow,true));bank.addView(text("Jede gelbe Scheibe gehört genau einem Spieler oder liegt im Vorrat.",12,muted,false));root.addView(bank);
      TextView distribute=text("SCHEIBEN VERTEILEN",13,muted,true);distribute.setPadding(0,22,0,8);root.addView(distribute);
      fromSpinner=new Spinner(this);toSpinner=new Spinner(this);
      ArrayList<String> names=new ArrayList<>();for(Player p:players)names.add(p.name);
      ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);
      fromSpinner.setAdapter(adapter);toSpinner.setAdapter(adapter);
      LinearLayout selectors=row();LinearLayout left=column(),right=column();left.addView(text("VON",11,muted,true));left.addView(fromSpinner);right.addView(text("AN",11,muted,true));right.addView(toSpinner);selectors.addView(left,new LinearLayout.LayoutParams(0,-2,1));selectors.addView(right,new LinearLayout.LayoutParams(0,-2,1));root.addView(selectors);
      TextView amountLabel=text("ANZAHL GELBER SCHEIBEN",11,muted,true);amountLabel.setPadding(0,12,0,4);root.addView(amountLabel);
      EditText amount=new EditText(this);amount.setText("1");amount.setTextColor(white);amount.setTextSize(20);amount.setInputType(2);amount.setSingleLine(true);amount.setBackground(shape(panel,14));amount.setPadding(14,0,14,0);root.addView(amount,new LinearLayout.LayoutParams(-1,52));
      Button transfer=button("Scheiben übertragen",yellow,()->{
        int a=fromSpinner.getSelectedItemPosition(),b=toSpinner.getSelectedItemPosition();if(a==b){toast("Wähle zwei verschiedene Spieler");return;}
        int n;try{n=Integer.parseInt(amount.getText().toString());}catch(Exception e){n=0;}
        if(n<1){toast("Gib mindestens 1 Scheibe ein");return;}
        Player src=players.get(a),dst=players.get(b);if(src.yellow<n){toast(src.name+" hat nicht genug gelbe Scheiben");return;}
        if(dst.yellow+n>13){toast("Der Empfänger hätte mehr als 13 gelbe Scheiben");return;}
        src.yellow-=n;dst.yellow+=n;if(dst.yellow==13 && dst.reds==0)dst.reds=1; if(dst.reds>=2){} render();
      });LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,52);tp.topMargin=10;root.addView(transfer,tp);
      Button shockout=button("Schock-out: rote Scheibe vergeben 🔴",red,()->{
        String[] opts=new String[players.size()];for(int i=0;i<players.size();i++)opts[i]=players.get(i).name;
        new AlertDialog.Builder(this).setTitle("Wer bekommt Rot?").setItems(opts,(d,which)->{Player chosen=players.get(which);if(chosen.reds<2)chosen.reds++;if(chosen.reds>=2){new AlertDialog.Builder(this).setTitle("Spiel verloren!").setMessage(chosen.name+" hat 2 rote Scheiben und verliert die Runde.").setPositiveButton("OK",null).show();}render();}).setNegativeButton("Abbrechen",null).show();
      });LinearLayout.LayoutParams so=new LinearLayout.LayoutParams(-1,52);so.topMargin=8;root.addView(shockout,so);
      TextView playersTitle=text("SPIELERSTAND  ·  "+players.size()+"/10",13,muted,true);playersTitle.setPadding(0,22,0,8);root.addView(playersTitle);
      list=column();root.addView(list);
      for(int i=0;i<players.size();i++){final int idx=i;Player p=players.get(i);LinearLayout card=column();card.setBackground(shape(panel,18));card.setPadding(14,12,14,12);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=10;list.addView(card,cp);
        LinearLayout top=row();top.addView(text(p.name,18,white,true),new LinearLayout.LayoutParams(0,-2,1));top.addView(text("🟡 "+p.yellow+"   "+"🔴 "+p.reds+"/2",14,white,true));card.addView(top);
        LinearLayout actions=row();Button rename=button("Name ändern",Color.rgb(65,68,77),()->{EditText e=new EditText(this);e.setText(p.name);new AlertDialog.Builder(this).setTitle("Spielername").setView(e).setNegativeButton("Abbrechen",null).setPositiveButton("Speichern",(d,w)->{String n=e.getText().toString().trim();if(!n.isEmpty())p.name=n;render();}).show();});actions.addView(rename,new LinearLayout.LayoutParams(0,44,1));
        if(players.size()>3){Space gap=new Space(this);actions.addView(gap,new LinearLayout.LayoutParams(8,1));Button remove=button("Entfernen",Color.rgb(65,68,77),()->{new AlertDialog.Builder(this).setTitle("Spieler entfernen?").setMessage("Gelbe Scheiben dieses Spielers gehen zurück in den Vorrat.").setNegativeButton("Abbrechen",null).setPositiveButton("Entfernen",(d,w)->{players.remove(idx);render();}).show();});actions.addView(remove,new LinearLayout.LayoutParams(0,44,1));}
        card.addView(actions);
      }
      LinearLayout add=row();add.setPadding(0,10,0,0);nameInput=new EditText(this);nameInput.setSingleLine(true);nameInput.setTextColor(white);nameInput.setHintTextColor(muted);nameInput.setHint("Spielername");nameInput.setPadding(12,0,12,0);nameInput.setBackground(shape(panel,14));add.addView(nameInput,new LinearLayout.LayoutParams(0,50,1));Space gap=new Space(this);add.addView(gap,new LinearLayout.LayoutParams(8,1));
      Button addBtn=button("+ Spieler",yellow,()->{String n=nameInput.getText().toString().trim();if(players.size()>=10){toast("Maximal 10 Spieler");return;}if(n.isEmpty())n="Spieler "+(players.size()+1);players.add(new Player(n));render();});add.addView(addBtn);root.addView(add);
      Button reset=button("Spiel komplett zurücksetzen",Color.rgb(65,68,77),()->new AlertDialog.Builder(this).setTitle("Alles zurücksetzen?").setMessage("Alle Scheiben gehen zurück in den Vorrat.").setNegativeButton("Abbrechen",null).setPositiveButton("Zurücksetzen",(d,w)->{for(Player p:players){p.yellow=0;p.reds=0;}render();}).show());LinearLayout.LayoutParams rr=new LinearLayout.LayoutParams(-1,50);rr.topMargin=18;root.addView(reset,rr);
      TextView foot=text("13 gelbe insgesamt · 2 rote Scheiben = Runde verloren",11,muted,false);foot.setPadding(0,18,0,12);root.addView(foot);
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}