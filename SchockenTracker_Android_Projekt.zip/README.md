# Schocken – Android Punkte-Zähler

## Features
- 3 bis 10 Spieler
- **Nur 13 gelbe Scheiben insgesamt**: gemeinsamer Vorrat; Scheiben werden von Spieler zu Spieler übertragen.
- Empfänger kann nie mehr als 13 gelbe Scheiben haben.
- Bei 13 gelben Scheiben wird automatisch eine rote Scheibe (halbe Strafe) markiert.
- Rote Scheibe bei Schock-out manuell vergeben.
- **Bei 2 roten Scheiben verliert der Spieler die Runde** und die App zeigt eine Meldung.
- Spieler umbenennen, hinzufügen und entfernen.

## APK bauen
1. Erstelle ein GitHub-Repository und lade alle Dateien und Ordner aus diesem Projekt hoch.
2. Öffne **Actions** und starte **Build Android APK**.
3. Nach erfolgreichem Build unter **Artifacts** `Schocken-debug-apk` herunterladen.
4. ZIP entpacken, `app-debug.apk` aufs Android-Handy kopieren und öffnen. Bei Nachfrage Installation aus dieser Quelle erlauben.

Die Scheibenstände werden aktuell nur während der laufenden App-Sitzung gespeichert.
